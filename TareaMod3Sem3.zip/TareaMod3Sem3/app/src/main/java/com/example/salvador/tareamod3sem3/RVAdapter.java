package com.example.salvador.tareamod3sem3;

        import android.support.v7.widget.CardView;
        import android.support.v7.widget.RecyclerView;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ImageView;
        import android.widget.TextView;
        import android.widget.Toast;
        import java.util.List;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.PetViewHolder>{
    List<Mascota> pets;

    RVAdapter(List<Mascota> pets){   // Indicar al Adapter los datos p el RecyclerView
        this.pets = pets;
    }  // Constructor

    public static class PetViewHolder extends RecyclerView.ViewHolder
                                       implements View.OnClickListener{
        CardView cv;
        TextView petName;
        TextView petRating;
        ImageView petFoto;
        ImageView hueso1;

        PetViewHolder(View itemView) {  // Constructor
            super(itemView);
            cv = (CardView)itemView.findViewById(R.id.cv);
            petName = (TextView)itemView.findViewById(R.id.petName);
            petRating = (TextView)itemView.findViewById(R.id.petRating);
            petFoto = (ImageView)itemView.findViewById(R.id.petFoto);
            hueso1=   (ImageView)itemView.findViewById(R.id.hueso1);
            petFoto.setOnClickListener(this);
            hueso1.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Log.d("********* spv ********", " " + v.getId() );
        }
    }

    @Override
    public int getItemCount() {
        return pets.size();
    }

    @Override  // Se invoca al inicializar el ViewHolder
    // Especifica el layout de c/item del RecyclerView
    public PetViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false);
        PetViewHolder pvh = new PetViewHolder(v);
        return pvh;
    }

    @Override    // Valores de los campos del cardview
    // similar a getView de un adapter de ListView

    public void onBindViewHolder(PetViewHolder petViewHolder, int position) {
        final Mascota pet = pets.get(position);
        petViewHolder.petName.setText(pet.petName);
        petViewHolder.petRating.setText(pet.petRating);
        petViewHolder.petFoto.setImageResource(pet.petFoto);
        petViewHolder.hueso1.setImageResource(R.drawable.hueso1);

    }
/*
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }
*/



}
