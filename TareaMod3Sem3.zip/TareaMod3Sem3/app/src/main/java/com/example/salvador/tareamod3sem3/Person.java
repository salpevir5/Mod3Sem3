package com.example.salvador.tareamod3sem3;

/**
 * Created by Salvador on 06/07/2016.
 */
public class Person {
    String name;
    String age;
    int photoId;

    Person(String name, String age, int photoId) {
        this.name = name;
        this.age = age;
        this.photoId = photoId;
    }
}
