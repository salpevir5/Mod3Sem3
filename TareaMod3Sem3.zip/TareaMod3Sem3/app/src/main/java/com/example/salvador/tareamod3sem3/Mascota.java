package com.example.salvador.tareamod3sem3;

public class Mascota {
    String petName;
    String petRating;
    int petFoto;
    public Mascota(String petName, String petRating, int petFoto) {
        this.petName = petName; this.petRating = petRating;  this.petFoto = petFoto;
    }
}


