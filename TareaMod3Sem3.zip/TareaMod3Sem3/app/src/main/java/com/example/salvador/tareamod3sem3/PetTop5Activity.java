package com.example.salvador.tareamod3sem3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class PetTop5Activity extends AppCompatActivity implements View.OnClickListener {
    Button regresar;
    private RecyclerView vistaPets;
    private List<Mascota> pets;

    public void msg(String s)  { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_top5);
        regresar = (Button)findViewById(R.id.regresar);
        regresar.setOnClickListener(this);
        vistaPets = (RecyclerView)findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        vistaPets.setLayoutManager(llm);
        initializeData(); //  msg("Initialized data");
        RVAdapter adapter = new RVAdapter(pets);
        vistaPets.setAdapter(adapter);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.regresar)
        { Toast.makeText(this,"regresando",Toast.LENGTH_LONG).show();
            Intent i1 = new Intent(this, MainActivity.class);
            startActivity(i1);
        }
    }

    private void initializeData(){
        pets = new ArrayList<>();
        pets.add(new Mascota("Spike", "7 ", R.drawable.perrito1));
        pets.add(new Mascota("Sultan", "2 ", R.drawable.perrito2));
        pets.add(new Mascota("Tom", "5 ", R.drawable.gatito2));
        pets.add(new Mascota("Neron", "4 ", R.drawable.perrito3));
        pets.add(new Mascota("Silver", "3 ", R.drawable.gatito1));

    }

}

