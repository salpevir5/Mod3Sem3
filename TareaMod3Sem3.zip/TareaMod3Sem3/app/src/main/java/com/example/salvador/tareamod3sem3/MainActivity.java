package com.example.salvador.tareamod3sem3;

import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.support.v7.widget.LinearLayoutManager;
        import android.support.v7.widget.RecyclerView;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.widget.Toast;
        import java.util.ArrayList;
        import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView vistaPets;
    //  rv.setHasFixedSize(true);   opcional
    private List<Mascota> pets;
    public void msg(String s)
    {Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);      // msg("onCreate1");
        setContentView(R.layout.activity_main);  // msg("onCreate2");
        vistaPets = (RecyclerView)findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        vistaPets.setLayoutManager(llm);
        initializeData();    // msg("Initialized data");
        RVAdapter adapter = new RVAdapter(pets);
        vistaPets.setAdapter(adapter);

        /* Detiene la aplicación
        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);   //support.v7.widget;
        */
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {case R.id.top5Mascotas:
           // msg("Top5Mascotas");
            Intent int1 = new Intent(this, PetTop5Activity.class);
            startActivity(int1);
            break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initializeData(){
        pets = new ArrayList<>();
        pets.add(new Mascota ("Silver", "3 ", R.drawable.gatito1));
        pets.add(new Mascota("Spike", "7 ", R.drawable.perrito1));
        pets.add(new Mascota("Tom", "5 ", R.drawable.gatito2));
        pets.add(new Mascota("Sultan", "2 ", R.drawable.perrito2));
        pets.add(new Mascota("Neron", "4 ", R.drawable.perrito3));
    }

}

